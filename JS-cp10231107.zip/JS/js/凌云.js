var rule = Object.assign(muban.短视,{
    title:'凌云影视',
    host:'https://www.lingyun.in',
url:'/channel/fyclass-fypage.html',
searchUrl:'/search.html?wd=**',
});