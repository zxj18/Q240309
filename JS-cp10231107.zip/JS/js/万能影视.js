var rule = Object.assign(muban.首图,{
title:'万能影视',
host:'https://wnvod.net',
});