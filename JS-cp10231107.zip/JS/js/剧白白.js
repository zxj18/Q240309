var rule = Object.assign(muban.首图2,{
title:'剧白白',
host:'https://jubaibai.cc',
url:'/vodshow/id/fyclass/page/fypage.html',
searchUrl:'/vodsearch**/page/fypage.html',
class_parse:'.stui-header__menu li:gt(0):lt(6);a&&Text;a&&href;/(.*?).html',
});